$(document).ready(function() {
  
  // Superfluous title animation
  $('#title').animate({
    opacity: .5,
    "margin-left": "+80px"
  }, 1500);
  
});